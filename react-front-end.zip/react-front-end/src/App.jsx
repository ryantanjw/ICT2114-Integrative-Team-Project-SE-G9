import React from "react";
import AppRoutes from "./AppRoutes.jsx";

function App() {
  return <AppRoutes />;
}

export default App;
